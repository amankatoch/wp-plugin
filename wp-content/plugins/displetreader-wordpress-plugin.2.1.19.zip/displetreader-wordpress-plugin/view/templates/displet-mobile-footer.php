<div id="displet-mobile-footer" class="<?php displetretsidx_the_default_mobile_styles_class(); ?>">
	<?php if ( displetretsidx_has_mobile_footer() ) : ?>
		<div class="displet-text">
			<?php displetretsidx_the_mobile_footer(); ?>
		</div>
	<?php endif; ?>
</div>

<?php wp_footer(); ?>
</body>
</html>