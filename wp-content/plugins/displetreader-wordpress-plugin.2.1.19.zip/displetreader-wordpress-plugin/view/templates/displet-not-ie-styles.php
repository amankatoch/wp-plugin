<!--[if !IE]> -->
	<link rel="stylesheet" type="text/css" href="<?php echo plugins_url( self::$_slug . '/includes/css/displet-not-ie-styles.css' ); ?>">
 <!-- <![endif]-->