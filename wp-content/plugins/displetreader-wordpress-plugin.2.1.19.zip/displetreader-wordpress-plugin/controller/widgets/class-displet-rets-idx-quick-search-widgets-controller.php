<?php

class DispletRetsIdxQuickSearchWidgetsController extends DispletRetsIdxPlugin {
	public static function register_widgets() {
		register_widget( 'DispletRetsIdxQuickSearchWidget' );
	}
}

?>