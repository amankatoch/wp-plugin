<?php

class DispletRetsIdxSidescrollerWidgetController extends DispletRetsIdxPlugin {
	public static function register_widget() {
		register_widget( 'DispletRetsIdxSidescrollerWidget' );
	}
}

?>