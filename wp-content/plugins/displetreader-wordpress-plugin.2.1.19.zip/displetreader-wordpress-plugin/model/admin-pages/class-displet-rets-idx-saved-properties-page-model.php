<?php

class DispletRetsIdxSavedPropertiesPageModel extends DispletRetsIdxAdminPagesModel {
	protected static function build_model() {

	}
}

?>