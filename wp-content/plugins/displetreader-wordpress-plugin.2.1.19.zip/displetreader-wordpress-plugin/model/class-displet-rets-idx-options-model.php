<?php

class DispletRetsIdxOptionsModel extends DispletRetsIdxPlugin {
	protected $_model;
	protected $_sections;
	protected $_settings;
}

?>