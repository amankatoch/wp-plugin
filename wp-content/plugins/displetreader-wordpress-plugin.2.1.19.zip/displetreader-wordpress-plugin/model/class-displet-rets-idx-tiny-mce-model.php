<?php

class DispletRetsIdxTinyMceModel extends DispletRetsIdxPlugin {
}

?>