=== ConverseJS ===
Contributors: Vipan Arora
Donate link: 
Tags: rss, audio ,esferasfot , feeds 
Requires at least: 3.8
Tested up to: 3.8
Stable tag: 1.0

Esferasoft Rss audio player is audio solution for rss . 

== Description ==

This plugin imports the audio from Rss channel and inserts them into wordpress blogs .
The blog link can also be shared email to various social networking websited like facebook,twitter , linkedIn .

Special Thanks:

* Aman Kumar for development
* Aman Katoch for testing
* Jatindar for designing 

Features

* Email 
* Facebook share 
* Twitter share 


== Installation ==

This section describes how to install the plugin and get it working.

1. Upload this directory to your plugins directory. It will create a 'wp-content/plugins/Esferasoft-rss-audio-player/‘ directory or install it via the WordPress.org plugin directory.
2. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==


== Screenshots ==

1. Front View
2. Rear View

== Changelog ==

= 1.0 =
* First stable version