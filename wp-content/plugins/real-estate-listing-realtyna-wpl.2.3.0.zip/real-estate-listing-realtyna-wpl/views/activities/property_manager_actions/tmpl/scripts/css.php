<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
div.pmanager_actions
{
    width: auto;
    height: auto;
    display: inline-block;
}
.wpl_finalized_message{color: #ff0000;}
</style>