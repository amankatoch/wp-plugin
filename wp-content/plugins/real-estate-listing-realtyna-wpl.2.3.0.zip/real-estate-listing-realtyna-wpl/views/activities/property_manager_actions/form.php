<?php
/** no direct access * */
defined('_WPLEXEC') or die('Restricted access');
?>
<p><?php echo __('No option!', WPL_TEXTDOMAIN); ?></p>