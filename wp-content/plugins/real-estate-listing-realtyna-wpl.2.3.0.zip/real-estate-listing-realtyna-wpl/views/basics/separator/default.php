<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');

$separator_str = '<span style="display: block; margin: 1px 0 4px -5px; padding: 0; height: 1px; line-height: 1px; background: #CCCCCC;"></span>';
?>