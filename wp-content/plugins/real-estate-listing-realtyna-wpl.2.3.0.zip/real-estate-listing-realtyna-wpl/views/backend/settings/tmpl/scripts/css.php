<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.wpl_st_label{display: block; float: left; width: 150px; padding: 0 5px;}
.wpl_sidebar_home{padding-bottom: 20px;}
.wpl_st_typeselect select{min-width: 100px;}
.wpl_setting_form_shortcode_container{border-bottom: 1px solid #999999; padding: 0 5px 2px;}
.wpl-bottom-nav{margin: 15px 0 0 0;}
.side-maintenance{float: left;}
.side-requirements{float: right;}
.wpl-maintenance-container ul li{cursor: pointer;}
.wpl-maintenance-container .wpl_ajax_loader{width: 20px; display: inline-block;}
.wpl-requirements-container ul li span.wpl-requirement-name{width: 120px;}
.wpl-requirements-container ul li span.wpl-requirement-require{width: 90px;}
.wpl-requirements-container ul li span.wpl-requirement-current{width: 90px;}
.wpl-requirements-container ul li span.wpl-requirement-status{width: 40px;}
.wpl_maintenance .wpl_show_message{margin-bottom: 15px;}
.wpl_server_offers{margin-top: 10px; text-align: center;}
.separator-name{padding-left: 30px; margin: 10px 0;}
hr{margin-bottom: 0;}
input.long{width: 500px;}
textarea.long{width: 500px; height: 200px;}
</style>