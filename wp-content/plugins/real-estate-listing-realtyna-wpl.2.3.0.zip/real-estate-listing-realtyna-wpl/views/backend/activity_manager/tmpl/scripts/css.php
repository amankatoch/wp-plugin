<?php
/** no direct access * */
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
#options_section label{width: 125px;}
.activity_manager_top_bar{margin: 0 0 10px 0;}
.wpl_right_section{float: right;}
.wpl_left_section{float: left;}
#activity_manager_filter{width: 500px;}
.clearfix{clear: both;}
.gray_tip{font-style: italic; color: #999999; font-size: 13px;}
.wpl_actions_td{width: 160px;}
</style>