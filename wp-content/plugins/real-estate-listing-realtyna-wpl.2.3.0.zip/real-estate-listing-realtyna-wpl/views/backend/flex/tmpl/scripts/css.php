<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.wpl_sidebar3{background: #d7f1ff; padding: 10px; border-radius: 3px; -moz-border-radius: 3px; -webkit-border-radius: 3px; float: none;}
.wpl_flex_modify_title{font-weight: bold; padding: 7px 0;}
.wpl_sidebar2{margin: 0;}
.flex-right-panel .panel-body{padding: 10px 8px !important;}
.wpl_flex_specificable_cnt{margin-left: 26px;}
.realtyna-lightbox-wp label.wpl_specific_label{text-align: left; width: 120px;}
</style>