<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.wpl_sidebar3{padding: 10px;}
.wpl_listing_modify_title{font-weight: bold; padding: 7px 0;}
.wpl_sidebar2{margin: 0;}
.wpl_listing_container label{display: inline-block; width: 120px; vertical-align: top;}
.wpl_listing_field_container_locations .wpl_listing_all_location_container{display: table-cell; padding-left: 3px;}
.wpl_listing_field_container_locations label[for=wpl_c_41]{display: table-cell;}
.wpl_listing_field_container_locations .wpl_listing_saved_span{display: table-cell; padding-left: 5px;}
.wpl_listing_location_level_keyword{width: 75px; display: block; float: left; padding-right: 10px;}
.wpl_message_container{margin: 30px 10px; font-size: 30px;}
.wpl_listing_field_container_rooms{padding: 10px 0;}
.wpl_room_list_container{margin-top: 10px;}
.video_tabs .selected{background: #cccccc;}
.wpl_video_embed_container{margin: 10px 0;}
.prow-textarea textarea.wpl_c_field_308{width: 60%;}
.pwizard-wp .after-finilize-wp .message-wp{width: 60%;}
</style>