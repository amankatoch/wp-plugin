<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.listing_types_icon_frame{ border:1px solid gray; float:left; margin:5px; border-radius:5px; position:relative}
.listing_types_icon_frame span.listing_types_icon_delete{width: 18px;height: 18px;background: rgb(202, 202, 202);border-radius: 8px;position: absolute;top: 1px;right: 1px; cursor:pointer}
.listing_types_icon_frame .wpl_ajax_loader{position:absolute; left:1px; top:1px}
.wpl-wp table.widefat td.wpl_sort_options_manager{width: 90px;}
#wpl_delete_listing_property_type_cnt .options div, #listing_type_list, #property_type_list{cursor: pointer; padding: 3px 10px;}
.wpl_button_cnt{text-align: right; padding: 10px 72px 0 0;}
</style>