<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.selectbox{width:110px;}
.selectboxmini{width:90px;}
.enabled_check{float:left;}
.unit_manager_panel{width:100%; margin-bottom:10px; height:30px; padding:5px 0px 5px 20px; font-weight:bold;}
</style>