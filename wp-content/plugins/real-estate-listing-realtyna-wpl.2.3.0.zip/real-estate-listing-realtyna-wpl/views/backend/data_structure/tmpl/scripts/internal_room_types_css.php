<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.selectbox{width:110px;}
.selectboxmini{width:90px;}
.enabled_check{float:left;}
.unit_manager_panel{width:100%; margin-bottom:10px; height:30px; padding:5px 0px 5px 20px; font-weight:bold;}
.right-side{width:60%;float:left;}
.left-side{width:35%;float:right;background-color:#f0f0f0;border:1px #DFDFDF solid;padding:10px;}
.icons_holder {
	line-height: 18px;
	margin: 10px;
	float: left;
	background-color: #184a7d;
	background-image: -moz-linear-gradient(top,#17568c,#1a3867);
	background-image: -webkit-gradient(linear,0 0,0 100%,from(#17568c),to(#1a3867));
	background-image: -webkit-linear-gradient(top,#17568c,#1a3867);
	background-image: -o-linear-gradient(top,#17568c,#1a3867);
	background-image: linear-gradient(to bottom,#17568c,#1a3867);
	background-repeat: repeat-x;
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#ff17568c', endColorstr='#ff1a3867', GradientType=0);
	border-top: 1px solid rgba(255,255,255,0.2);
	padding: 5px;
	color: #FFF;
	text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.8);
	-moz-text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.8);
	-webkit-text-shadow: 1px 1px 1px rgba(0, 0, 0, 0.8);
	-moz-border-radius: 10px;
	-webkit-border-radius: 10px;
	border-radius: 10px;
	width: 40px;
	height: 50px;
	text-align: center;
}
</style>