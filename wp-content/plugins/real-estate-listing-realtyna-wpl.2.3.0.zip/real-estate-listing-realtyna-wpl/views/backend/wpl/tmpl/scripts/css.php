<?php
/** no direct access * */
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.wpl_addons_message{padding: 0 10px;}
.wpl_addon_message{font-style: italic !important; cursor: pointer; color: #666666;}
.wpl_addon_name{cursor: default;}
.wpl_ni_addons_container{padding: 0 20px;}
.wpl_ni_addon_container{margin: 15px 0;}
.wpl_ni_addon_subject .wpl_ni_addons_addon_name{font-weight: bold !important;}
.wpl_ni_addon_subject .readmore_link{font-size: 13px; font-style: italic; margin-left: 15px;}
.side-ni-addons{margin-right: 1%;}
.side-support{width: 50% !important;}
.side-changes{width: 29% !important; margin-left: 1% !important;}
.wpl_realtyna_credentials_container{padding: 0 0 20px 40px;}
.wpl_realtyna_credentials_container .wpl_realtyna_credentials_tip{font-style: italic !important; color: #999999;}
#wpl_realtyna_credentials_check span.action-btn{cursor: default;}
.wpl_version{padding-left: 10px; color: #ffb42b;}
.side-statistic1{margin-right: 1% !important;}
.side-statistic2{width: 50% !important;}
.side-announce{width: 100% !important;}
.side-addons p.pro-message{margin: 10px 20px;}
</style>