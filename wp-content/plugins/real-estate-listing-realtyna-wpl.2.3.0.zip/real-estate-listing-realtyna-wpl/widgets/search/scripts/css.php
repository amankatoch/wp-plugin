<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<!-- Marvin Developing CSS -->
<style type="text/css">
.wpl_search_field_container{display: block; margin: 15px 0px; font-size: 11px; border-left: 3px #FFF solid; padding: 5px 8px;}
.wpl_search_field_container > label:first-child{display: block; color: #C00; font-weight: bold; font-size: 13px;}
.wpl_search_field_container:hover{background: #EEE; border-left: 3px #CCC solid;}
.MD_SEP > .wpl_search_field_container{display: none;}
.MD_SEP > .wpl_search_field_container:first-child{display: block; cursor: pointer;}
.MD_SEP > .wpl_search_field_container > label:first-child{color: #F60;}
.MD_SEP > .wpl_search_field_container:first-child > label:first-child{display: block; color: #C00; font-weight: bold; font-size: 13px;}
.MD_SEP > .wpl_search_field_container:first-child:after{content: "Separator : Click On Me";}
.wpl_span_block{display: block;}
</style>