<?php
/** no direct access * */
defined('_WPLEXEC') or die('Restricted access');
?>
<a class="search-tab" href="#wpl-search-tab-content-<?php echo $this->widget_id . '-' . $category->id; ?>">
    <span>
        <?php echo $category->name; ?>
    </span>
</a>

