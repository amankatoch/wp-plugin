<?php
/** no direct access **/
defined('_WPLEXEC') or die('Restricted access');
?>
<style type="text/css">
.wpl_agents_widget_backend_form{margin: 10px 0;}
.wpl_agents_widget_backend_form input[type='text']{width: 100%;}
.wpl_agents_widget_backend_form select{width: 100%;}
</style>