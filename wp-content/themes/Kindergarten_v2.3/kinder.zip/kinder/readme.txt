WordPress 4.0 Ready

WordPress 3+ Custom Menu Support

Responsive design

Blog post layout changing – for each page you can choose between:

    Right Sidebar

    Left Sidebar

    Top sidebar

    Fullwidth

    Fullscreen

Easy logo replacement

Sociable Icons section in header and Social widget

Substitute standard WP gallery, video and audio in single post

jQuery tabs, jQuery accordion, sliders, etc

SEO Ready

Favicon uploader

Flex slider include

Swiper slider include

Revolution Slider Ready (Compatible)

Royal Slider Ready (Compatible)

Advanced user account page

All post formats support

Typography

Shortcodes

    Blogger
    
    E-mailer

    Sliders

    Columns

    And many more

Audioplayer included

10 Custom Widgets

Homepage slider

Easy inserting sliders to pages and posts

Easy video including from Youtube and Vimeo   

Social icons section on author’s block

Contact form validator

Comments with reply functionality (multiple levels depth)

Works and looks similar in all major browsers: Internet Explorer, Firefox, Opera, Safari, Google Chrome

Documentation included
